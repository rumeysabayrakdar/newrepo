const fs = require('node:fs'),
  assert = require('node:assert/strict'),
  { JSDOM } = require('jsdom');
const memory = () => {
  const m = new Map();
  return {
    getItem: (k) => m.get(k) || null,
    setItem: (k, v) => m.set(k, String(v)),
    removeItem: (k) => m.delete(k),
  };
};
const html = fs.readFileSync('downloads/Arcelik-AppStore-Admin.html', 'utf8');
assert(!/src="(?:assets\/|https?:)/.test(html));
let errors = [];
const dom = new JSDOM(html, {
  url: 'file:///Arcelik-AppStore-Admin.html',
  runScripts: 'dangerously',
  beforeParse(w) {
    Object.defineProperty(w, 'localStorage', { value: memory() });
    Object.defineProperty(w, 'sessionStorage', { value: memory() });
    w.structuredClone = structuredClone;
    w.matchMedia = () => ({ matches: false });
    w.scrollTo = () => {};
    w.confirm = () => true;
    w.HTMLElement.prototype.scrollIntoView = () => {};
    w.HTMLDialogElement.prototype.showModal = function () {
      this.open = true;
    };
    w.HTMLDialogElement.prototype.close = function () {
      this.open = false;
    };
    w.addEventListener('error', (e) =>
      errors.push(e.error?.stack || e.message),
    );
  },
});
const w = dom.window,
  q = (s) => w.document.querySelector(s),
  pause = () => new Promise((r) => setTimeout(r, 30));
async function until(f) {
  for (let i = 0; i < 100; i++) {
    if (f()) return;
    await pause();
  }
  throw Error('Timeout: ' + w.document.body.textContent.slice(-500));
}
function input(e, v) {
  e.value = v;
  e.dispatchEvent(new w.Event('input', { bubbles: true }));
}
(async () => {
  await until(() => q('[data-manage]'));
  q('.admin-heading [data-home]')?.click();
  q('[data-destination=web]').click();
  await until(() => q('.web-app-card'));
  w.open = () => ({});
  const atlas = [...w.document.querySelectorAll('a[href^="#html-open="]')].find(
    (a) => decodeURIComponent(a.getAttribute('href')).includes('web:atlas'),
  );
  assert(atlas);
  atlas.click();
  q('[data-manage]').click();
  await until(() => q('.dashboard-stats'));
  assert(q('.report-origin').textContent.includes('browser'));
  assert.equal(q('.dashboard-stats b').textContent, '0');
  assert.equal(q('.dashboard-stats').querySelectorAll('b')[1].textContent, '1');
  q('[data-admin-group="appearance"]').click();
  q('[data-admin-tab="languages"]').click();
  input(q('#add-language [name=name]'), 'Español');
  input(q('#add-language [name=code]'), 'es');
  q('#add-language').dispatchEvent(
    new w.Event('submit', { bubbles: true, cancelable: true }),
  );
  await until(() => q('#translation-language').value === 'es');
  assert(q('[data-ui-language] option[value=es]'));
  assert.equal(errors.length, 0, errors.join('\n'));
  console.log(
    'PASS: standalone HTML boots offline, records browser-only web visits with zero downloads, and registers an additional language.',
  );
})()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => w.close());
