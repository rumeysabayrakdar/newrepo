# Corrected appstore deployment

The exported project connected to db_appstore_d8qt2h but expected db_final_ydg9lm. Both base and Test Database:Name now match db_appstore_d8qt2h. Test remains selected. The database-name and Test/Production isolation checks remain enforced.

This package matches the latest final application code, including EN/TR application definitions, gateway-safe saves and open-attempt outcomes. The supplied catalogue is identical. Existing saved database data is retained on startup. The original Norm .NET registry mirrors and supplied public origin are preserved.

A database password was embedded in the uploaded source. It is excluded from this clean package along with generated .bekows deployment metadata and unused legacy browser-auth scripts. Norm must supply the current database connection securely during import. No credentials or database contents are included.

Upload to the existing appstore project. Accept only src/AppStore.Web/appsettings.json for the project's Test database; reject Production replacements. Keep port 8080 and Setup SQL empty. Ensure any saved Database__Name override also equals db_appstore_d8qt2h, rather than blank or the final project's name. Do not reset either database.

The supplied Hosting:TrustedPublicOrigin remains https://final.norm.ar.arcelik. If this clone is served at a different address, the platform must set that exact public origin before browser saves will succeed. No unverified hostname or trusted gateway range has been invented.

Validation: the repaired JSON configuration was exercised with the same verified final backend in an isolated PostgreSQL instance. Startup health returned database connected and Test; six apps and all five tables were present, and an edit persisted after a fresh read. Fixture connection credentials were supplied externally. No live Norm database was accessed or changed.
