# Current test suites

Run npm test for ui.cjs. PostgreSQL suites are integration.cjs, workflow.cjs, migration.cjs and isolation.cjs. See TESTING.md for prerequisites. Node is development tooling only; the backend is .NET.
